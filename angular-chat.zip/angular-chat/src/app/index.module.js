(function() {
  'use strict';

  angular
    .module('angularChat', ['ngAnimate', 'ngCookies', 'ngSanitize', 'ngResource', 'ui.router', 'ngMaterial','ngStorage', 'ngEmbed']);

})();
